// ============================================================
//  TECH'AUTO DMS — Serveur local (réseau du garage, 5 postes)
//  Aucune dépendance : Node.js 18+ suffit.  Lancement : node server.js
// ============================================================
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');

const PORT = process.env.PORT || 8080;
const DATA = path.join(__dirname, 'data');
const DBF = path.join(DATA, 'db.json');
const BACKUPS = path.join(DATA, 'sauvegardes');
fs.mkdirSync(BACKUPS, { recursive: true });

// --- État en mémoire (chargé depuis le disque) -----------------------------
let state = { version: 1, data: null };
if (fs.existsSync(DBF)) {
  try { state = JSON.parse(fs.readFileSync(DBF, 'utf8')); }
  catch (e) { console.error('⚠ db.json illisible — restaurez une sauvegarde du dossier data/sauvegardes'); process.exit(1); }
}

// Écriture atomique : on écrit un fichier temporaire puis on le renomme
// (si le courant saute pendant l'écriture, l'ancien fichier reste intact)
function save() {
  state.version++;
  const tmp = DBF + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(state));
  fs.renameSync(tmp, DBF);
}

// Sauvegarde quotidienne automatique (une par jour, 60 jours conservés)
function backup() {
  if (!fs.existsSync(DBF)) return;
  const f = path.join(BACKUPS, 'db-' + new Date().toISOString().slice(0, 10) + '.json');
  if (!fs.existsSync(f)) fs.copyFileSync(DBF, f);
  const files = fs.readdirSync(BACKUPS).filter(x => x.startsWith('db-')).sort();
  while (files.length > 60) fs.unlinkSync(path.join(BACKUPS, files.shift()));
}
backup();
setInterval(backup, 3600 * 1000);

function readBody(req) {
  return new Promise((resolve, reject) => {
    let b = '';
    req.on('data', c => { b += c; if (b.length > 80e6) req.destroy(); });
    req.on('end', () => { try { resolve(JSON.parse(b || '{}')); } catch (e) { reject(e); } });
  });
}
function send(res, code, obj) {
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(obj));
}

http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://local');
    const p = url.pathname;

    // ----- API -----
    if (p === '/api/db' && req.method === 'GET') return send(res, 200, state);
    if (p === '/api/version') return send(res, 200, { version: state.version });

    if (req.method === 'POST' && p.startsWith('/api/')) {
      const b = await readBody(req);

      if (p === '/api/init') {                 // premier lancement uniquement
        if (!state.data) { state.data = b.data; save(); }
        return send(res, 200, state);
      }
      if (p === '/api/replace') {              // restauration d'une sauvegarde
        backup();
        state.data = b.data; save();
        return send(res, 200, { version: state.version });
      }
      if (!state.data) return send(res, 409, { error: 'base non initialisée' });

      if (p === '/api/op') {                   // modification d'un enregistrement
        const d = state.data;
        if (b.op === 'upsert') {
          const arr = d[b.coll] || (d[b.coll] = []);
          const i = arr.findIndex(x => x.id === b.item.id);
          if (i >= 0) arr[i] = b.item; else arr.push(b.item);
        } else if (b.op === 'delete') {
          d[b.coll] = (d[b.coll] || []).filter(x => x.id !== b.id);
        } else if (b.op === 'settings') {
          d.settings = b.settings;
        }
        save();
        return send(res, 200, { version: state.version });
      }
      if (p === '/api/next') {                 // numérotation unique (factures, OR...)
        const key = b.type + b.year;
        const c = state.data.compteurs || (state.data.compteurs = {});
        c[key] = (c[key] || 0) + 1;
        save();
        return send(res, 200, { n: c[key], version: state.version });
      }
    }

    // ----- Fichiers -----
    if (p === '/' || p === '/index.html') {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      return fs.createReadStream(path.join(__dirname, 'index.html')).pipe(res);
    }
    res.writeHead(404); res.end('Introuvable');
  } catch (e) {
    console.error(e);
    send(res, 500, { error: String(e.message || e) });
  }
}).listen(PORT, '0.0.0.0', () => {
  console.log('\n  TECH\'AUTO DMS démarré ✔\n');
  console.log('  Sur ce poste      : http://localhost:' + PORT);
  for (const list of Object.values(os.networkInterfaces()))
    for (const n of list || [])
      if (n.family === 'IPv4' && !n.internal)
        console.log('  Sur les 4 autres  : http://' + n.address + ':' + PORT);
  console.log('\n  Données : ' + DBF + '\n  Ne fermez pas cette fenêtre.\n');
});
